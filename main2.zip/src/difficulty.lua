-- dificulty.lua

Difficulty = {}

function Difficulty:load()

    self.background = Assets.Diff_background

    self.easy_sprite = Assets.Diff_easy_sprite
    self.normal_sprite = Assets.Diff_normal_sprite
    self.hard_sprite = Assets.Diff_hard_sprite

    self.icons_width = self.easy_sprite:getWidth()
    self.icons_height = self.easy_sprite:getHeight()
    self.icons_y = love.graphics.getHeight() / 2 - love.graphics.getHeight() / 3


    -- Fácil
    self.easyDifficulty = {
        x = love.graphics.getWidth() / 2 - love.graphics.getWidth() / 3,
        y = self.icons_y,
        sx = 1,
        sy = 1,
        textX = 1,
        textY = 1,
    }
    self.easyDifficulty.textX = self.easyDifficulty.x + self.icons_width / 2 - 35
    self.easyDifficulty.textY = self.icons_y + self.icons_height

    -- Normal
    self.normalDifficulty = {
        x = love.graphics.getWidth() / 2 - self.normal_sprite:getWidth() / 2,
        y = self.icons_y,
        sx = 1,
        sy = 1,
        textX = 1,
        textY = 1,
    }
    self.normalDifficulty.textX = self.normalDifficulty.x + self.icons_width / 2 - 50
    self.normalDifficulty.textY = self.icons_y + self.icons_height

    -- Dificil
    self.hardDifficulty = {
        x = love.graphics.getWidth() / 2 + love.graphics.getWidth() / 6,
        y = self.icons_y,
        sx = 1,
        sy = 1,
        textX = 1,
        textY = 1,
    }
    self.hardDifficulty.textX = self.hardDifficulty.x + self.icons_width / 2 - 35
    self.hardDifficulty.textY = self.icons_y + self.icons_height

end

function Difficulty:update(dt)
    -- Facil
    self:updateMouseHover(dt, self.easyDifficulty.x, self.easyDifficulty.y, self.easyDifficulty)
    -- Normal
    self:updateMouseHover(dt, self.normalDifficulty.x, self.normalDifficulty.y, self.normalDifficulty)
    -- Dificil
    self:updateMouseHover(dt, self.hardDifficulty.x, self.hardDifficulty.y, self.hardDifficulty)
end

function Difficulty:draw()
    love.graphics.setNewFont(30)

    love.graphics.draw(self.background, 0, 0)

    -- Fácil
    love.graphics.draw(self.easy_sprite, self.easyDifficulty.x , self.easyDifficulty.y, nil, self.easyDifficulty.sx, self.easyDifficulty.sy)
    love.graphics.print("Easy", self.easyDifficulty.textX, self.easyDifficulty.textY)

    -- Normal
    love.graphics.draw(self.normal_sprite, self.normalDifficulty.x, self.normalDifficulty.y, nil, self.normalDifficulty.sx, self.normalDifficulty.sy)
    love.graphics.print("Normal", self.normalDifficulty.textX, self.normalDifficulty.textY)

    -- Difícil
    love.graphics.draw(self.hard_sprite, self.hardDifficulty.x, self.hardDifficulty.y, nil, self.hardDifficulty.sx, self.hardDifficulty.sy)
    love.graphics.print("Hard", self.hardDifficulty.textX, self.hardDifficulty.textY)


    --love.graphics.draw(drawable (Drawable), x (number), y (number), r (number), sx (number), sy (number), ox (number), oy (number), kx (number), ky (number))
end

-- Função De FeedBack Do Mouse
function Difficulty:updateHoverEffect(v, dt, maxSX, maxSY, scale_speed, sign)
    if v.sx < maxSX and v.sy < maxSY then
        v.textY = v.textY + scale_speed*200 * dt -- texto
        v.textX = v.textX + scale_speed*100 * dt -- texto
        v.sx = v.sx + scale_speed * dt * sign
        v.sy = v.sy + scale_speed * dt * sign
    end
end
 
-- Função para Atualizar a Função de Passada do Mouse
function Difficulty:updateMouseHover(dt, x, y, v)
    if mouseX < x + self.icons_width and
       mouseX > x and
       mouseY < y + self.icons_height and
       mouseY > y then
        self:updateHoverEffect(v, dt, 1.1, 1.1, 1, 1)
       else 
        if v.sx > 1 and v.sy > 1 then
            v.textY = v.textY - 1*200 * dt -- texto
            v.textX = v.textX - 1*100 * dt -- texto
            v.sx = v.sx + 1 * dt * -1
            v.sy = v.sy + 1 * dt * -1
        end
    end
end