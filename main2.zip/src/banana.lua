-- banana.lua

Banana = {}
bananas = {}

function Banana:load()
    self.sprite = Assets.banana
    self.width = self.sprite:getWidth()
    self.height = self.sprite:getHeight()
    self.bullet_sprite = Assets.banana_bullet
end

function Banana:update(dt)
    for i = #bananas, 1, -1 do
        local v = bananas[i]
        -- Movimento
        if v.x < v.maxX then
            v.x = v.x + (v.speed * dt)
        end

        -- Tempo e Atirar
        if v.ShootTimer > 0 then
            v.ShootTimer = v.ShootTimer - 1 * dt
        end
        if v.ShootTimer <= 0 then
            v.ShootTimer = 3
            -- Atira
            Shoot(v.x, v.y, Egg.x, Egg.y, v.width, v.height, 1000, self.bullet_sprite)
        end

        -- Colisão com a Bala
        for bi = #bullets, 1, -1 do  -- vai em reverso, otimização ¯\_(ツ)_/¯ 
            local bv = bullets[bi]
            if bv.x > v.x and
               bv.x < v.x + v.width and
               bv.y > v.y and
               bv.y < v.y + v.height and bv.bType ~= 'B' then
                table.remove(bullets, bi)
                v.hit = true
            end
        end

        -- Dano
        if v.hit then
            v.health = v.health - bullet_damage 
            local ceffectx = v.x+v.width/2
            -- Efeitos
            CircEffect:create(0, 100, ceffectx, v.y+v.height/2, 150, 3, {1, 0, 0}, 1, "explode")
            DEffect:create(v, bullet_damage, {1, 0, 0, 1}, '-')
            v.hit = false
        end

        -- Vida
        if v.health <= 0 then
            Coin:spawn(v, v.x + v.width / 2, v.y)
            table.remove(bananas, i)
            love.audio.play(done)
        end
    end
end

function Banana:draw()
    for i,v in pairs(bananas) do
        --local angle = math.atan2((Egg.y - v.y), (v.x - Egg.x))
        angle = 1
        love.graphics.draw(v.sprite, v.x, v.y, nil, 1, 1, 1, 1)
    end
end

function Banana:create(x, y)
    local banana = {
        health = 100,
        x = x,
        y = y,
        width = self.width,
        height = self.height,
        speed = 200,
        sprite = self.sprite,
        maxX = 50,
        ShootTimer = 2,
        angle = 1,
        hit = false,
    }
    table.insert(bananas, banana)
end