-- handle_waves.lua

function spawnK(n)
    for i = 1, n, 1 do
        Kangaroo:spawn()
    end
end
function spawnS(n)
    for i = 1, n, 1 do
        Shark:create(-200, floorheight)
    end
end
function checkWaveFinished()
    if next(kangaroos) == nil and next(sharks) == nil then
        return true 
    else
        return false
    end
end
function spawnWave(waveNumber)
    numberofkangaroos = waveNumber * 2
    numberofsharks = waveNumber - 1
    spawnK(numberofkangaroos)
    if numberofkangaroos ~= 0 then
        spawnS(numberofsharks)
    end
end

timer = 0
function handlewaves(dt)
    if startwaves and not tips and wave < maxwaves then
        if wavefinished then
            timer = timer + dt

            if timer >= 3 then
                spawnWave(wave)
                love.audio.play(wavesound)
                wavefinished = false  
                wave = wave + 1     
                Kangaroo.rotation_speed = Kangaroo.rotation_speed + 1
                timer = 0  
            end
        else
            if checkWaveFinished() then
                wavefinished = true  
            end
        end
    elseif wave == maxwaves and checkWaveFinished() then
        gamefinished = true
    end
end