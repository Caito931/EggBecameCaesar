-- dificulty.lua

Difficulty = {}

function Difficulty:load()

    self.background = love.graphics.newImage("assets/new/difficulty_background.png")

    self.easy_sprite = love.graphics.newImage("assets/difficulty/1_easy.png")
    self.normal_sprite = love.graphics.newImage("assets/difficulty/2_normal.png")
    self.hard_sprite = love.graphics.newImage("assets/difficulty/3_hard.png")

    self.icons_height = self.easy_sprite:getHeight()
    self.icons_y = love.graphics.getHeight() / 2 - love.graphics.getHeight() / 3

    self.icons_width = self.easy_sprite:getWidth()

    self.e_x = love.graphics.getWidth() / 2 - love.graphics.getWidth() / 3
    self.n_x = love.graphics.getWidth() / 2 - self.normal_sprite:getWidth() / 2
    self.h_x = love.graphics.getWidth() / 2 + love.graphics.getWidth() / 6
end

function Difficulty:update(dt)
end

function Difficulty:draw()
    love.graphics.setNewFont(30)

    love.graphics.draw(self.background, 0, 0)

    -- Fácil
    love.graphics.draw(self.easy_sprite, self.e_x , self.icons_y)
    love.graphics.print("Easy", self.e_x + self.icons_width / 2 - 35, self.icons_y + self.icons_height)

    -- Normal
    love.graphics.draw(self.normal_sprite, self.n_x, self.icons_y)
    love.graphics.print("Normal", self.n_x + self.icons_width / 2 - 50, self.icons_y + self.icons_height)

    -- Difícil
    love.graphics.draw(self.hard_sprite, self.h_x, self.icons_y)
    love.graphics.print("Hard", self.h_x + self.icons_width / 2 - 35, self.icons_y + self.icons_height)
end