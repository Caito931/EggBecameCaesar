-- pressed_functions

-- Mouse
function love.mousepressed(x , y , button , isTouch )
    local abletoshot = true
    if button == 1 and not gameover and not mmenuopen and not difficultuselection and Egg.velY == 0 then
        if x < Egg.jumpbutton_x + Egg.jumpbutton_width and
        x > Egg.jumpbutton_x and 
        y < Egg.jumpbutton_y + Egg.jumpbutton_height and
        y > Egg.jumpbutton_y then
            Egg.jumped = true
            Egg:jump()
            abletoshot = false
        end
    end
    local tripleshootdistance = 50
    if button == 2 and not gameover and not mmenuopen and not difficultuselection and abletoshot then
        -- Tiro Triplo
        gamepadshoot = false
        Shoot(Egg.x, Egg.y, Egg.width, Egg.height)
        Shoot(Egg.x + tripleshootdistance, Egg.y + tripleshootdistance, Egg.width, Egg.height)
        Shoot(Egg.x - tripleshootdistance, Egg.y - tripleshootdistance, Egg.width, Egg.height)
        shootscounts = shootscounts + 1 -- Debuff
    end
    if button == 1 and not gameover and not mmenuopen and not difficultuselection and abletoshot then
        gamepadshoot = false
        Shoot(Egg.x, Egg.y, Egg.width, Egg.height)
        shootscounts = shootscounts + 1
    end
    if button == 1 and not gameover and not mmenuopen and not difficultuselection and abletoshot and isTouch then
        Shoot(Egg.x, Egg.y, Egg.width, Egg.height)
        shootscounts = shootscounts + 1
    end
    if button == 1 and not gameover and mmenuopen  or isTouch then
        if x < MainMenu.start_x + MainMenu.start_width and
        x > MainMenu.start_x and 
        y < MainMenu.start_y + MainMenu.start_height and
        y > MainMenu.start_y then
            Transition.currentscene = 1
            Transition.show = true
            love.audio.play(click)
        end
    end
    if button == 1 and not gameover and mmenuopen  or isTouch then
        if x < MainMenu.quit_x + MainMenu.quit_width and
        x > MainMenu.quit_x and 
        y < MainMenu.quit_y + MainMenu.quit_height and
        y > MainMenu.quit_y then
            love.event.quit()
        end
    end
    --------------------------------------------------------------
    -- Dificuldades --
    -- Fácil
    if button == 1 and not gameover and not mmenuopen and difficultuselection then
        if x < Difficulty.e_x + Difficulty.icons_width and
           x > Difficulty.e_x and
           y < Difficulty.icons_y + Difficulty.icons_height and
           y > Difficulty.icons_y then
            difficulty = 'easy'
        end
    end
    -- Normal
    if button == 1 and not gameover and not mmenuopen and difficultuselection then
        if x < Difficulty.n_x + Difficulty.icons_width and
           x > Difficulty.n_x and
           y < Difficulty.icons_y + Difficulty.icons_height and
           y > Difficulty.icons_y then
            difficulty = 'normal'
        end
    end
    -- Difícil
    if button == 1 and not gameover and not mmenuopen and difficultuselection then
        if x < Difficulty.h_x + Difficulty.icons_width and
           x > Difficulty.h_x and
           y < Difficulty.icons_y + Difficulty.icons_height and
           y > Difficulty.icons_y then
            difficulty = 'hard'
        end
    end

    if button == 1 and not gameover and not mmenuopen and difficultuselection and difficulty ~= nil then
        Transition.currentscene = 2
        love.audio.play(click)
        -- Dificuldade 
        if difficulty == "easy" then
            maxshootcounts = 15
            sc_multiplier = 13.3
            maxwaves = 10
            Kangaroo.health = 50
            Kangaroo.damage = 3
        end
        if difficulty == "normal" then
            sc_multiplier = 10
            maxshootcounts = 20
            maxwaves = 15
            Kangaroo.health = 100
            Kangaroo.damage = 5
        end
        if difficulty == "hard" then
            sc_multiplier = 5
            maxshootcounts = 40
            maxwaves = 20
            Kangaroo.health = 200
            Kangaroo.damage = 20
        end
        Transition.show = true
    end
    --------------------------------------------------------------
end
-- Key
function love.keypressed(key, scancode, isrepeat)
    -- Menu Cima e Baixo
    if mmenuopen then
        if key == "up" and MainMenu.finger_y > MainMenu.start_y then
            if not click:isPlaying() then
                love.audio.play(click)
            end
            MainMenu.finger_y = MainMenu.finger_y - 75
        end
        if key == "down" and MainMenu.finger_y < MainMenu.newart_y  then
            if not click:isPlaying()  then
                love.audio.play(click)
            end
            MainMenu.finger_y = MainMenu.finger_y + 75
        end
        if key == "return" then
            love.audio.play(click)
            if MainMenu.finger_y == MainMenu.start_y then
                Transition.currentscene = 1
                Transition.show = true
            end
            if MainMenu.finger_y == MainMenu.quit_y then
                love.event.quit()
            end
            if MainMenu.finger_y == MainMenu.newart_y then
                EnableNewArt()
            end
        end
    end
    if key == "k" then
        Kangaroo:spawn()
    end
    if key == "s" then
        Shark:create(-200, floorheight)
    end
    -- Restart
    if key == "r" and not mmenuopen then
        if gameover then
            Restart()
        end
    end
    if key == "m" and not mmenuopen and gamefinished then
        Restart()
    end
    if not gameover and not mmenuopen and not difficultuselection then
        if key == "e" then
            tips = false
            startwaves = true
        end
        -- Mira
        if key == "f2" then
            enableaimline = not enableaimline
        end
    end

    -- Debug
    if key == "f1" then
        debug = not debug
        if not debug then
            bullet_damage = 25
        end
    end
    if key == "f3" then
        showfps = not showfps
    end
    if key == "o" then
        Background.background = love.graphics.newImage("assets/new/background2.png")
    end
end

--[[
function love.joystickpressed(joystick, button)
    if button == 3 then
        if not gameover and not mmenuopen and not difficultuselection then
            gamepadshoot = true
            Shoot(Egg.x, Egg.y, Egg.width, Egg.height)
            shootscounts = shootscounts + 1
        end
    end
    if button == 1 then
        if not gameover and not mmenuopen and not difficultuselection then
            Egg:jump()
        end
    end
end
]]