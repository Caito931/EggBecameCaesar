-- utilities.lua

Util = {}

function Util:load()
    self.gascan_sprite = love.graphics.newImage("assets/new/u_gas_can.png")
    self.medkit_sprite = love.graphics.newImage("assets/new/u_medkit.png")
    self.ammo_sprite = love.graphics.newImage("assets/new/u_ammo.png")
    self.util_width = 80
    self.util_height = 80
    self.gravity = 500
    self.randomutilid = math.random(1, 3)
    self.randomchance = math.random(1, 5) 

    -- Table para Armazenas os Ultilizáveis
    utils = {}
end

function Util:update(dt)
    for i = #utils, 1, -1 do
        local v = utils[i]

        if v.y  <= floorheight then
            v.y = v.y + v.velocity * dt
        end

        -- Detecção de Colisão
        if Egg.x + Egg.width > v.x and Egg.x < v.x + v.width and 
           Egg.y + Egg.height > v.y and Egg.y < v.y + v.height then
                local coloreffect = {1, 1, 1, 1} -- cor dependendo do tipo
                -- 1/4 Um Quarto
                if v.id == 1 then -- Gasolina
                    Egg.fuel = Egg.fuel + (100/4) 
                    coloreffect = {255 / 255, 150 / 255, 0 / 255, 1}
                end
                if v.id == 2 then -- Kit Médico
                    Egg.health = Egg.health + (100/4)
                    coloreffect = {50 / 255, 255 / 255, 0 / 255, 1}
                end
                if v.id == 3 then -- Munição
                    Egg.ammo = Egg.ammo + (100/4)
                    coloreffect = {255 / 255, 255 / 255, 0 / 255, 1}
                end
                -- Efeitos
                DEffect:create(v, 100/4, coloreffect, '+')
                CircEffect:create(0, 50, v.x + v.width / 2, v.y + v.height / 2, 150, 2.5, {coloreffect[1], coloreffect[2], coloreffect[3]}, 1, "explode")

                -- Remove
                table.remove(utils, i)
                --if not utilsound:isPlaying() then
                    love.audio.play(utilsound)
                --end
        end
    end
end

function Util:draw()
    -- Desenha
    for i,v in pairs(utils) do
        love.graphics.draw(v.sprite, v.x, v.y)
    end
end

function Util:create(v, id, value)
    local utilsprite
    if id == 1 then
        utilsprite = self.gascan_sprite
    elseif id == 2 then
        utilsprite = self.medkit_sprite
    elseif id == 3 then
        utilsprite = self.ammo_sprite
    end
    util = {
        x = v.x,
        y = floorheight - self.util_height,
        width = self.util_width,
        height = self.util_height,
        sprite = utilsprite,
        id = id,
        value = value,
        velocity = 200
    }
    table.insert(utils, util)
end

function generateRUtilId(min, max)
    return math.random(min, max)
end

function generateRUtilChance(min, max)
    return math.random(min, max)
end