function love.conf(t)
    t.window.width = 1280
    t.window.height = 800
    t.title = "Egg Became Caesar"
    t.window.icon = "assets/new/icon.png"
    t.console = false
end